"""Ghazal Tanavade

Main program for the Pythonic Flashcard Quiz Bonanza!
Let's get silly, stylish, and oh-so-pythonic.
"""

from deck import Deck
from flashcard import Flashcard
from multiple_choice_card import MultipleChoiceCard
from study_session import StudySession
from true_false_card import TrueFalseCard


def flashcard_banner():
    """Print a playful flashcard quiz banner."""
    print(r"""
╔══════════════════════════════════════════╗
║      PYTHON FLASHCARD QUIZ THINGY        ║
║         Let's get this bread(🍞)!        ║
║                    🐍                    ║
╚══════════════════════════════════════════╝
""")

def main():
    """Run the main program for the flashcard quiz system."""
    flashcard_banner()
    print("🐍 Welcome to the Python Flashcard Quiz Thingy! 🐍")
    print("Get ready to learn type shi🧘\n")

    # creating silly flashcard deck.
    basic_card = Flashcard(
        "What sound does a Python make? (hint: it's not meow)", "hiss")
    mc_card = MultipleChoiceCard(
        "Which of these is a valid Python variable name?",
        "b",
        {"a": "2cool4school", "b": "cool_var", "c": "hello-world!"}
    )
    mc_card2 = MultipleChoiceCard(
        "Which keyword is used to define a function in Python?",
        "a",
        {"a": "def", "b": "func", "c": "lambda"}
    )
    tf_card2 = TrueFalseCard(
        "True or False: Lists in Python can contain different data types.",
        "t"
    )
    tf_card = TrueFalseCard(
        "True or False: Ghazal is da #goat.",
        "t"
    )

    # Build the deck
    silly_deck = Deck()
    silly_deck.add_cards([basic_card, mc_card, tf_card, mc_card2, tf_card2])

    # Print the deck lineup
    print("\nHere's your painless deck for today:")
    print(silly_deck)
    print("\nLet's play! Answer with your best guess❤️‍🔥\n")

    # Start a study session
    session = StudySession(silly_deck)
    session.start()

    print("\n🐍 Thanks for playing! 🐍")
    print("hopefully you learned something:D")

if __name__ == "__main__":
    main()
