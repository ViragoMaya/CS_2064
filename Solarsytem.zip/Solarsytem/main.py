"""
Main module for project 2

This script initializes a solar system, populating it with the real 
planet data and then facts about the planets and the system itself. 

"""

from star import Star
from planet import Planet
from solar_system import SolarSystem

def main():
    
    sun = Star("Sun", 1.989e30, "G-type")

    solar_system = SolarSystem("Solar System", sun)


    # Real planetary data (approximate)
    # name, mass, radius, distance_from_sun, orbital_period
    # source: 
    planets_data = [
        ("Mercury", 3.285e23, 2439.7, 57.9, 87.97),
        ("Venus", 4.867e24, 6051.8, 108.2, 224.70),
        ("Earth", 5.972e24, 6371, 149.6, 365.26),
        ("Mars", 6.39e23, 3389.5, 227.9, 686.98),
        ("Jupiter", 1.898e27, 69911, 778.5, 4332.82),
        ("Saturn", 5.683e26, 58232, 1434, 10755.70),
        ("Uranus", 8.681e25, 25362, 2871, 30687.15),
        ("Neptune", 1.024e26, 24622, 4495, 60190.03)
    ]
    # Adds planets to the solar system
    for name, mass, radius, distance, period in planets_data:
        planet = Planet(name, mass, radius, distance, period)
        solar_system.add_planet(planet)

   # Prints out the whole solar system!
    print("\n⋆⭒˚.⋆☾.𖥔 ݁ ˖.Our Solar System.⋆⭒˚.⋆☾.𖥔 ݁ ˖\n")
    print(solar_system)

    #Prints a list of the plant names
    print("The planets in our solar system are:", 
          solar_system.list_planets())

    #Habitable planets (by our assignment logic)
    print("The habitable planets in our solar system are:", 
          solar_system.find_habitable_planets())

# For each planet, print its orbital speed and surface gravity
    print("\n\nPlanetary Details⋆⭒˚.⋆🔭:\n")
    for planet in solar_system.planets:
        print(f"{planet.name}:")
        print(f"  Orbital speed: {planet.calculate_orbital_speed():.2f} km/s")
        print(f"  Surface gravity: {planet.calculate_surface_gravity():.2f} m/s^2")
        print(f"  Planet type: {planet.planet_type()}")
        print(f"  Habitable: {'Yes' if planet.is_habitable() else 'No'}\n")


if __name__ == '__main__':
    main()
